<?php


// set global things >>
$project_name = 'TUT: C++ Unit Test Framework';


// set keywords and description >>
$keywords = 'C++ test-driven unit tests TUT framework STL';
$description = 'TUT is a pure C++ unit test framework. Its name - TUT - stands for Template Unit Tests.';





?>